---
date: 2004-02-17 09:10:28
author: Jay Cuthrell
tags:
   - essays
slug: who-am-i-kidding
title: Who am I kidding
cover: 268279913.jpg

---


I’d like to see a skit on SNL about the “Who Am I Kidding” calling plan from Verizon.

Video: Urban man age 25-35. Bad hair. Frumpy. Bad choice of clothing. Sitting on bus stop bench in city. Checking his cell phone and seeing an empty list when selecting “Received Calls”.

Voice over: You’ve got a great cell phone. It takes pictures. Tons of games. It even plays soundtrack to Lord of the Rings when you get the weather report update. You even get unlimited minutes for people that call you and unlimited minutes to call anyone nationwide.

Video: Man looks into camera, has a big grin, then nods affirmatively and makes a “yeah, I’m cool” face.

Voice over: But the bill is, well, hard to justify given your social life. That’s why Verizon is now offering the “Who Am I Kidding Plan”. Sure, you have a cell phone, but let’s be realistic. Nobody calls you. Really. We mean it. Nobody calls you.

Video: Man face sinks into a depressing expression and kind of nods a sheepish affirmation.

Voice over: And most likely, nobody ever will. You see, you're just not popular. In fact, we know from our own call analysis that people don’t even answer your calls. That’s right. They go straight to their voice mail. We’re excited to offer this calling plan to you and others like you. We’ll even make it so you don’t have to wait for the other person you call to let it ring into their voice mail. We’ll send your calls straight there. You’ll feel better knowing your message was left and you didn’t have to put the person you called on the spot. Nobody likes a pest and with the “Who Am I Kidding Plan” you won’t be!

Video: Man looks into camera, has a big grin, then nods affirmatively and makes a “maybe I am cool” face then a “hey, wait a minute……” face

Voice over: That’s right! And, with our nationwide all digital network your voice mails will be crystal clear when they forward through it or don’t hit delete quickly enough to avoid hearing it!

Video: The man looks up just as the Verizon “Can you hear me now?” guy is walking by the bench. The man is visibly excited and tries to make eye contact but the Verizon guy just acts like he didn’t see him and rushes to put his cell phone to his ear (upside down) to perpetrate like he is taking an important call as he shuffles away from the man quickly. Man makes face as if to say, “Yeah, hey no problem, you're busy, I’ll catch you later” as his face sinks back into the same depressing expression.

Voice over: Verizon. We never stop working for you. Even if nobody cares if you exist.

